<select name="state" id="state" class="form-control">
	<option value="">STATE</option>
	<option @if($selected_state == 'Alabama')selected="selected" @endif value="Alabama">Alabama</option>
	<option @if($selected_state == 'Alaska')selected="selected" @endif value="Alaska">Alaska</option>
	<option @if($selected_state == 'American Samoa')selected="selected" @endif value="American Samoa">American Samoa</option>
	<option @if($selected_state == 'Arizona')selected="selected" @endif value="Arizona">Arizona</option>
	<option @if($selected_state == 'Arkansas')selected="selected" @endif value="Arkansas">Arkansas</option>
	<option @if($selected_state == 'Armed Forces Africa')selected="selected" @endif value="Armed Forces Africa">Armed Forces Africa</option>
	<option @if($selected_state == 'Armed Forces Americas')selected="selected" @endif value="Armed Forces Americas">Armed Forces Americas</option>
	<option @if($selected_state == 'Armed Forces Canada')selected="selected" @endif value="Armed Forces Canada">Armed Forces Canada</option>
	<option @if($selected_state == 'Armed Forces Europe')selected="selected" @endif value="Armed Forces Europe">Armed Forces Europe</option>
	<option @if($selected_state == 'Armed Forces Middle East')selected="selected" @endif value="Armed Forces Middle East">Armed Forces Middle East</option>
	<option @if($selected_state == 'Armed Forces Pacific')selected="selected" @endif value="Armed Forces Pacific">Armed Forces Pacific</option>
	<option @if($selected_state == 'California')selected="selected" @endif value="California">California</option>
	<option @if($selected_state == 'Colorado')selected="selected" @endif value="Colorado">Colorado</option>
	<option @if($selected_state == 'Connecticut')selected="selected" @endif value="Connecticut">Connecticut</option>
	<option @if($selected_state == 'Delaware')selected="selected" @endif value="Delaware">Delaware</option>
	<option @if($selected_state == 'District of Columbia')selected="selected" @endif value="District of Columbia">District of Columbia</option>
	<option @if($selected_state == 'Federated States Of Micronesia')selected="selected" @endif value="Federated States Of Micronesia">Federated States Of Micronesia</option>
	<option @if($selected_state == 'Florida')selected="selected" @endif value="Florida">Florida</option>
	<option @if($selected_state == 'Georgia')selected="selected" @endif value="Georgia">Georgia</option>
	<option @if($selected_state == 'Guam')selected="selected" @endif value="Guam">Guam</option>
	<option @if($selected_state == 'Hawaii')selected="selected" @endif value="Hawaii">Hawaii</option>
	<option @if($selected_state == 'Idaho')selected="selected" @endif value="Idaho">Idaho</option>
	<option @if($selected_state == 'Illinois')selected="selected" @endif value="Illinois">Illinois</option>
	<option @if($selected_state == 'Indiana')selected="selected" @endif value="Indiana">Indiana</option>
	<option @if($selected_state == 'Iowa')selected="selected" @endif value="Iowa">Iowa</option>
	<option @if($selected_state == 'Kansas')selected="selected" @endif value="Kansas">Kansas</option>
	<option @if($selected_state == 'Kentucky')selected="selected" @endif value="Kentucky">Kentucky</option>
	<option @if($selected_state == 'Louisiana')selected="selected" @endif value="Louisiana">Louisiana</option>
	<option @if($selected_state == 'Maine')selected="selected" @endif value="Maine">Maine</option>
	<option @if($selected_state == 'Marshall Islands')selected="selected" @endif value="Marshall Islands">Marshall Islands</option>
	<option @if($selected_state == 'Maryland')selected="selected" @endif value="Maryland">Maryland</option>
	<option @if($selected_state == 'Massachusetts')selected="selected" @endif value="Massachusetts">Massachusetts</option>
	<option @if($selected_state == 'Michigan')selected="selected" @endif value="Michigan">Michigan</option>
	<option @if($selected_state == 'Minnesota')selected="selected" @endif value="Minnesota">Minnesota</option>
	<option @if($selected_state == 'Mississippi')selected="selected" @endif value="Mississippi">Mississippi</option>
	<option @if($selected_state == 'Missouri')selected="selected" @endif value="Missouri">Missouri</option>
	<option @if($selected_state == 'Montana')selected="selected" @endif value="Montana">Montana</option>
	<option @if($selected_state == 'Nebraska')selected="selected" @endif value="Nebraska">Nebraska</option>
	<option @if($selected_state == 'Nevada')selected="selected" @endif value="Nevada">Nevada</option>
	<option @if($selected_state == 'New Hampshire')selected="selected" @endif value="New Hampshire">New Hampshire</option>
	<option @if($selected_state == 'New Jersey')selected="selected" @endif value="New Jersey">New Jersey</option>
	<option @if($selected_state == 'New Mexico')selected="selected" @endif value="New Mexico">New Mexico</option>
	<option @if($selected_state == 'New York')selected="selected" @endif value="New York">New York</option>
	<option @if($selected_state == 'North Carolina')selected="selected" @endif value="North Carolina">North Carolina</option>
	<option @if($selected_state == 'North Dakota')selected="selected" @endif value="North Dakota">North Dakota</option>
	<option @if($selected_state == 'Northern Mariana Islands')selected="selected" @endif value="Northern Mariana Islands">Northern Mariana Islands</option>
	<option @if($selected_state == 'Ohio')selected="selected" @endif value="Ohio">Ohio</option>
	<option @if($selected_state == 'Oklahoma')selected="selected" @endif value="Oklahoma">Oklahoma</option>
	<option @if($selected_state == 'Oregon')selected="selected" @endif value="Oregon">Oregon</option>
	<option @if($selected_state == 'Palau')selected="selected" @endif value="Palau">Palau</option>
	<option @if($selected_state == 'Pennsylvania')selected="selected" @endif value="Pennsylvania">Pennsylvania</option>
	<option @if($selected_state == 'Puerto Rico')selected="selected" @endif value="Puerto Rico">Puerto Rico</option>
	<option @if($selected_state == 'Puerto Rico')selected="selected" @endif value="Puerto Rico">Rhode Island</option>
	<option @if($selected_state == 'South Carolina')selected="selected" @endif value="South Carolina">South Carolina</option>
	<option @if($selected_state == 'South Dakota')selected="selected" @endif value="South Dakota">South Dakota</option>
	<option @if($selected_state == 'Tennessee')selected="selected" @endif value="Tennessee">Tennessee</option>
	<option @if($selected_state == 'Texas')selected="selected" @endif value="Texas">Texas</option>
	<option @if($selected_state == 'Utah')selected="selected" @endif value="Utah">Utah</option>
	<option @if($selected_state == 'Vermont')selected="selected" @endif value="Vermont">Vermont</option>
	<option @if($selected_state == 'Virgin Islands')selected="selected" @endif value="Virgin Islands">Virgin Islands</option>
	<option @if($selected_state == 'Virginia')selected="selected" @endif value="Virginia">Virginia</option>
	<option @if($selected_state == 'Washington')selected="selected" @endif value="Washington">Washington</option>
	<option @if($selected_state == 'West Virginia')selected="selected" @endif value="West Virginia">West Virginia</option>
	<option @if($selected_state == 'Wisconsin')selected="selected" @endif value="Wisconsin">Wisconsin</option>
	<option @if($selected_state == 'Wyoming')selected="selected" @endif value="Wyoming">Wyoming</option>

</select>