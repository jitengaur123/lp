Hi,

Welcome to amaha.com

Username : {{ $mailData['user_name'] }}
Password : {{ $mailData['password'] }}